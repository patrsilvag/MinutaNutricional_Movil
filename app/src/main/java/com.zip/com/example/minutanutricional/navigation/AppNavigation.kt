package com.example.minutanutricional.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.minutanutricional.model.Receta

import com.example.minutanutricional.screens.PantallaLogin
import com.example.minutanutricional.screens.PantallaRegistro
import com.example.minutanutricional.screens.PantallaRecuperar
import com.example.minutanutricional.screens.PantallaMinuta
import com.example.minutanutricional.screens.PantallaDetalle


// --------------------
// NAVEGACIÓN SIMPLE
// --------------------
@Composable
fun AppNavigation() {
    var pantallaActual by remember { mutableStateOf("login") }
    var recetaSeleccionada by remember {
        mutableStateOf<com.example.minutanutricional.model.Receta?>(null)
    }


    Surface(modifier = Modifier.fillMaxSize()) {
        when (pantallaActual) {
            "login" -> PantallaLogin(
                onLoginSuccess = { pantallaActual = "menu" },
                onIrARegistro = { pantallaActual = "registro" },
                onIrARecuperar = { pantallaActual = "recuperar" }
            )

            "registro" -> PantallaRegistro(onVolver = { pantallaActual = "login" })

            "recuperar" -> PantallaRecuperar(onVolver = { pantallaActual = "login" })

            "menu" -> PantallaMinuta(
                onLogout = { pantallaActual = "login" },
                onVerDetalle = { Receta ->
                    recetaSeleccionada = Receta
                    pantallaActual = "detalle"
                }
            )

            "detalle" -> {
                val r = recetaSeleccionada
                if (r == null) {
                    pantallaActual = "menu"
                } else {
                    PantallaDetalle(
                        receta = r,
                        onVolver = { pantallaActual = "menu" }
                    )
                }
            }
        }
    }
}