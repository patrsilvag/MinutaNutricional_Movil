package com.example.minutanutricional.model

data class Receta(
    val dia: String,
    val nombre: String,
    val calorias: Int,
    val recomendacion: String
)